# Palm Palace Hotel — production-ready foundation

A premium hotel website and operations foundation for Palm Palace Hotel, Bahir Dar, Ethiopia.

## Included
- Cinematic luxury homepage with responsive AVIF/WebP imagery.
- 51-room inventory with 302 and 507 initially Out of Service.
- Direct booking with exact room-number availability and server-side pricing.
- Reception walk-in booking.
- Staff portal with Super Admin, Reception and Finance roles.
- Super Admin room state controls, user management and audit log.
- PostgreSQL/Supabase schema and database-backed staff sessions.
- Login rate limiting and secure password hashing.
- SEO metadata, Hotel JSON-LD, Open Graph, sitemap and robots.
- English / Amharic toggle foundation.
- Reduced-motion and keyboard-accessible interactions.

## Important
This repository does **not** invent payment-provider credentials or CNET API details. The production payment adapter becomes active only after the hotel obtains an approved merchant/gateway contract and its exact API/webhook specification. CNET synchronization likewise requires an official vendor API/contract.

## Run
1. Copy `.env.example` to `.env`.
2. Create a PostgreSQL/Supabase database and set `DATABASE_URL`.
3. Set `SESSION_SECRET`, `SUPER_ADMIN_USERNAME`, and `SUPER_ADMIN_PASSWORD`.
4. `npm install`
5. `npm start`

For image optimization, keep originals in `source-assets/` and run `npm run optimize-images`.

See `docs/PRODUCTION-CHECKLIST.md` for launch requirements.

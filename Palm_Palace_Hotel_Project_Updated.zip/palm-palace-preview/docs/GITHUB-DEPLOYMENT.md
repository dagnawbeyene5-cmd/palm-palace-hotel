# Palm Palace Hotel — GitHub deployment plan

## Recommended architecture
- **GitHub** — source code, version history, pull requests.
- **Supabase Postgres** — production database.
- **Render (or another Node-compatible host)** — Express server + public website + staff portal.
- **Payment provider** — official CBE merchant integration or a licensed Ethiopian gateway after merchant onboarding.
- **CNET ERP/PMS** — integrate only after CNET supplies an API/connector and credentials.

## Database migration
The current `server.js` is already written for PostgreSQL and the Supabase schema is in `supabase/schema.sql`.

Set these production environment variables on the server:
- `NODE_ENV=production`
- `DATABASE_URL=...`
- `SESSION_SECRET=...`
- `SUPER_ADMIN_USERNAME=...`
- `SUPER_ADMIN_PASSWORD=...`
- `PUBLIC_SITE_URL=https://your-domain`
- payment gateway variables after merchant onboarding
- CNET API variables after vendor confirmation

Never commit `.env` or production secrets.

## First GitHub commit
```bash
git init
git add .
git commit -m "feat: Palm Palace Hotel production foundation"
git branch -M main
git remote add origin <YOUR-GITHUB-REPOSITORY>
git push -u origin main
```

## Before public launch
1. Create the production Supabase database and run `supabase/schema.sql`.
2. Deploy the Node server from GitHub.
3. Add environment variables in the host dashboard.
4. Connect the real payment gateway and verify signed webhooks.
5. Confirm CNET integration requirements with the hotel/CNET vendor.
6. Add the real hotel logo, 360° panorama and verified social URLs.
7. Replace placeholder review text with reviews that are legally/operationally approved for publication.
8. Configure the real domain, HTTPS, absolute sitemap/canonical URLs and analytics.

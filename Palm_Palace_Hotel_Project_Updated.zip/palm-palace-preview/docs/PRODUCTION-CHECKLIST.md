# Palm Palace Hotel — production checklist

## Implemented in this version
- PostgreSQL/Supabase repository for production data.
- Database-backed Express sessions with `connect-pg-simple` when `DATABASE_URL` is configured.
- Login rate limiting (10 attempts / 15 minutes per limiter window).
- Server-side room/date/price validation and transactional room locking to prevent double booking.
- 51 rooms seeded; rooms 302 and 507 start Out of Service.
- Super Admin can change any room to Available, Out of Service or Maintenance.
- Reception walk-in bookings and online bookings share the same inventory.
- Finance access is role protected.
- Audit logs and room-state history.
- Optimized WebP + AVIF image variants; responsive `<picture>` markup; lazy loading below the fold.
- Accessible image alt text, focus states, skip link and reduced-motion support.
- Hotel JSON-LD, Open Graph metadata, canonical link and sitemap/robots files.
- English / Amharic language toggle foundation.
- Scroll reveal, restrained parallax, tactile buttons and gallery lightbox without a heavy animation dependency.

## Required before a real launch
1. Create a Supabase/PostgreSQL project and set `DATABASE_URL`.
2. Set a strong `SESSION_SECRET` and Super Admin credentials. Never commit `.env`.
3. Run `supabase/schema.sql` once if you want to pre-create the schema; the server also creates compatible tables on startup.
4. Confirm the hotel's official payment gateway/merchant API and webhook contract. Do not substitute a fake payment success response.
5. Configure the gateway environment variables and test successful, failed, cancelled and duplicate webhook cases.
6. Confirm whether CNET ERP/PMS provides an official API. If yes, implement and test a two-way room/reservation sync using the vendor's documented contract.
7. Replace/extend the supplied hotel photos with final approved media. Run `npm run optimize-images` whenever source images change.
8. Set `PUBLIC_SITE_URL` and the real production domain; update sitemap/canonical generation if the host needs absolute URLs.
9. Deploy behind HTTPS on a Node-compatible host; configure secure cookies and proxy trust.
10. Run Lighthouse/PageSpeed, keyboard navigation, mobile, low-bandwidth, booking concurrency and payment webhook tests.

// Production image build helper. Uses ImageMagick installed on the build machine.
const fs=require('fs');const path=require('path');const {execFileSync}=require('child_process');
const src=path.join(__dirname,'..','public','assets');const out=path.join(src,'optimized');fs.mkdirSync(out,{recursive:true});
for(const file of fs.readdirSync(src)){if(!/\.(jpe?g|png)$/i.test(file))continue;const input=path.join(src,file);const base=file.replace(/\.[^.]+$/,'');
  execFileSync('magick',[input,'-auto-orient','-resize','1920x1920>','-strip','-quality','78',path.join(out,base+'.webp')]);
  execFileSync('magick',[input,'-auto-orient','-resize','1920x1920>','-strip','-quality','55',path.join(out,base+'.avif')]);
}
console.log('Optimized images written to public/assets/optimized');
